import 'package:flutter/material.dart';
import 'widgets.dart/gradient_button.dart';
import 'profile_page.dart';

class ActivateContinuePage extends StatelessWidget {
  const ActivateContinuePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/image.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 300,
                height: 150,
                padding: EdgeInsets.all(14),
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 94, 157, 209),
                  borderRadius: BorderRadius.circular(20),
                ),

                child: Column(
                  children: const [
                    SizedBox(height: 12),
                    Text(
                      'Please enter key to continue',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    SizedBox(height: 12),
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Enter purchase code',
                        hintStyle: TextStyle(
                          color: Color.fromARGB(153, 0, 0, 0),
                        ),
                        border:
                            InputBorder.none, // if inside a custom container
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20.0),
              SizedBox(
                width: 300,
                height: 50,
                child: GradientButton(
                  text: 'Activate & Continue',
                  gradient: const LinearGradient(
                    colors: [Color(0xFF0A6ED1), Color(0xFF6BCF2E)],
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ProfilePage(),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 20.0),
              Text(
                'Click here to go back',
                style: TextStyle(
                  color: const Color.fromARGB(255, 66, 180, 70),
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
