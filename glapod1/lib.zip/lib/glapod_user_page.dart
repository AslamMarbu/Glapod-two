import 'package:flutter/material.dart';

class GlapodUserPage extends StatelessWidget {
  const GlapodUserPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
